const scrapingConcorrenteBarbosa = require("./concorrenteBarbosa.js");
const scrapingConcorrenteBomLugar = require("./concorrenteBomLugar.js");

module.exports = {
  scrapingConcorrenteBarbosa,
  scrapingConcorrenteBomLugar
};