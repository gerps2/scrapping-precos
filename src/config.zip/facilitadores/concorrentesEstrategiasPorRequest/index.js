const scrapingPorRequestConcorrenteBarbosa = require("./concorrenteBarbosaPorRequest.js");
const scrapingPorRequestConcorrenteBomLugar = require("./concorrenteBomLugarPorRequest.js");

module.exports = {
  scrapingPorRequestConcorrenteBarbosa,
  scrapingPorRequestConcorrenteBomLugar
};